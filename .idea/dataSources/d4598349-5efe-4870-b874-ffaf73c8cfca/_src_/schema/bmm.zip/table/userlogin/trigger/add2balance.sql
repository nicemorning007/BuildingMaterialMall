CREATE TRIGGER add2balance
AFTER INSERT ON userlogin
FOR EACH ROW
  INSERT INTO balance(userId,balance) VALUES(new.id,0);
