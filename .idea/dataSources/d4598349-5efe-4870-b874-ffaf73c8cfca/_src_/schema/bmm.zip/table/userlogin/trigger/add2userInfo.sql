CREATE TRIGGER add2userInfo
AFTER INSERT ON userlogin
FOR EACH ROW
  INSERT INTO userInfo(userId,username) VALUES(new.id,new.username);
