CREATE TRIGGER add2goodsDesc
AFTER INSERT ON goodsbase
FOR EACH ROW
  INSERT INTO goodsDesc(goodsId,cate) VALUES(new.id,new.cate);
